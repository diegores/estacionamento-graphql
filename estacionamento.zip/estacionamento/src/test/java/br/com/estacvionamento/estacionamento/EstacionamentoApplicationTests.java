package br.com.estacvionamento.estacionamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstacionamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
